module.exports = {
  title: "Rockstar всё же ускорит загрузку ПК-версии GTA Online",
  views: "1573",
  createdAt: "2021-03-16T08:39:25+00:00",
  img: "/images/tags-bell/tags-bell.png",
  type: ["Оптимизация", "JSON", "Игра", "Баги и ошибки"],
  comments: [
    "Я: подгружаю 10 мб JSON в 4х потоках\nЧуваки с новостей: УСКОРИЛ ЗАГРУЗКУ НА 70%, ЦЕЛЫХ 10 МЕГАБАЙТ!!11!",
    "Ростислав Рубан, Не загрузку десяти мегабайт а шесть минут обработки этих 10 мегабайт",
  ],
  html: '<!--[--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Представители Rockstar Games отреагировали на появление любительской модификации для GTA V, ускоряющей загрузку онлайн-режима.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Внезапно, компания не стала подавать на разработчика в суд, а наоборот поблагодарила его и пообещала выпустить официальное обновление со схожими исправлениями в ближайшее время, <a href="https://www.theverge.com/2021/3/15/22332421/grand-theft-auto-online-slow-load-times-fan-made-patch">пишет</a> The Verge.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f><a href="https://media.tproger.ru/uploads/2021/03/1-33.jpg"></a></p><!--]--><!--[--><blockquote class="tp-content-hint" fullwidth="true" data-type="hint" data-v-640486f3>После тщательного изучения [ситуации] мы можем подтвердить, что игрок t0st действительно раскрыл аспект игрового кода, связанный со временем загрузки ПК-версии GTA Online, который можно было бы улучшить. В результате мы внесли некоторые изменения, которые будут реализованы в предстоящем обновлении.</blockquote><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Напомним, что в конце февраля 2021 года пользователь под ником t0st рассказал об ускорении загрузки GTA Online.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Как оказалось, главной причиной замедления процесса было использование одного потока процессора для обработки 10 МБ JSON-файла. И всё это он выяснил и исправил, не имея доступа к исходному коду самой игры.</p><!--]--><!--[--><div class="tp-embed" data-type="embed" data-v-a1dfa206><span class="tp-embed-plug" data-v-a1dfa206></span></div><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Источник: <a href="https://www.theverge.com/2021/3/15/22332421/grand-theft-auto-online-slow-load-times-fan-made-patch">The Verge</a></p><!--]--><!--]-->',
  original:
    "https://tproger.ru/news/rockstar-vsjo-zhe-uskorit-zagruzku-pk-versii-gta-online/",
  id: 151604,
  link: "https://tproger.ru/news/rockstar-vsjo-zhe-uskorit-zagruzku-pk-versii-gta-online/",
  slug: "rockstar-vsjo-zhe-uskorit-zagruzku-pk-versii-gta-online",
};
