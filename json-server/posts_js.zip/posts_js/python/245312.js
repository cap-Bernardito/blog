module.exports = {
  title: "Математическая задача о холмах",
  views: "291",
  createdAt: "2023-08-28T09:04:22+00:00",
  img: "/images/tags-bell/tags-bell.png",
  type: ["Python"],
  comments: [],
  html: '<!--[--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Эммет владеет землей c N холмов высотой от 0 до 100 метров и хотел бы зарегистрировать её как лыжный тренировочный лагерь.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Территория может быть лыжней только в том случае, если разница в высоте между самым высоким и самым низким холмом составляет 17 метров и менее. Поэтому хозяину может потребоваться увеличить высоту одних холмов и уменьшить высоту других. Он умеет менять высоту только на целочисленные величины.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Стоимость изменения высоты рассчитывается по формуле δ^2. Например, увеличить метровый холм до высоты четырех метров стоит (4 – 1) ^ 2 = 9К.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Определите с помощью Python минимальную сумму, которую землевладелец должен заплатить, чтобы превратить свою землю в спортивный комплекс.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Данные задачи – высоты холмов:</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f><code class="tp-inline-code language-none lazy-code">5, 20, 4, 1, 24, 21</code></p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Напишите в комментариях, как бы вы решали подобную задачу с помощью Python. В следующей статье мы разберем лучшие решения.</p><!--]--><!--]-->',
  original: "https://tproger.ru/articles/matematicheskaya-zadacha-o-holmah/",
  id: 245312,
  link: "https://tproger.ru/articles/matematicheskaya-zadacha-o-holmah/",
  slug: "matematicheskaya-zadacha-o-holmah",
};
