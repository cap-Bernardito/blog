module.exports = {
  title: "Четвёртый раунд битвы языков программирования 2022",
  views: "10114",
  createdAt: "2022-12-16T08:00:47+00:00",
  img: "/images/tags-bell/tags-bell.png",
  type: [
    "JavaScript",
    "Java",
    "Языки программирования",
    "TypeScript",
    "Rust",
    "Лучший язык 2022",
  ],
  comments: [
    "За Rust обидно. Хороший язык, попавший в этом раунде под каток Java",
    ", Да потому, что тупое бессмысленное мероприятие, даже с оговоркой шуточное. Хотите выяснить народную любовь, пусть каждый расставит языки по своим предпочтениям, потом и считайте. А тут просто опять сравнивают круглое с пушистым.",
    "Тот кто придумал / пропустил эту статью / голосование - убейся об стену. Ты бесполезен если реально поставил такое голосование.",
    "Спойлер:Финал Python - C#",
    "Mr Vi, Медленный против неоригинального",
  ],
  html: '<!--[--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Стартует четвертый раунд битвы за звание лучшего языка программирования в 2022 году. В этот раз за между собой будут бороться:</p><!--]--><!--[--><ul class="tp-content-list" style="" data-type="list" data-v-705dc74d><!--[--><li class="tp-content-list__item" data-v-705dc74d>JavaScript и TypeScript;</li><li class="tp-content-list__item" data-v-705dc74d>Java и Rust.</li><!--]--></ul><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Третий раунд закончился победой PHP над Ruby с отрывом всего в 100 голосов, победой Kotlin над Swift с отрывом в 600 голосов. Результаты прошлого раунда можно посмотреть <a href="https://tproger.ru/articles/tretij-raund-bitvy-jazykov-programmirovanija-v-2022-godu/">здесь</a>.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Подпишитесь на тег <a href="https://tproger.ru/tag/luchshij-jazyk-2022/">Лучший язык 2022</a> и следите за обновлениями в личной ленте, чтобы не пропустить новые раунды битвы.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f><a href="https://media.tproger.ru/uploads/2022/12/IMG_4585.jpg"></a></p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Голосование по четвёртому раунду продлится до 17 декабря 2022 года. Опросы будут закрыты в 11:00 по МСК.</p><!--]--><!--[--><!----><!--]--><!--[--><!----><!--]--><!--]-->',
  original:
    "https://tproger.ru/articles/chetvjortyj-raund-bitvy-jazykov-programmirovanija-2022/",
  id: 234864,
  link: "https://tproger.ru/articles/chetvjortyj-raund-bitvy-jazykov-programmirovanija-2022/",
  slug: "chetvjortyj-raund-bitvy-jazykov-programmirovanija-2022",
};
