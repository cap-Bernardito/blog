module.exports = {
  title:
    "Космический интернет OneWeb может заработать в России до конца 2021 года",
  views: "1136",
  createdAt: "2021-05-28T18:56:40+00:00",
  img: "/images/tags-bell/tags-bell.png",
  type: ["Интернет", "Pet-проекты", "Космос"],
  comments: [],
  html: '<!--[--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Около часа назад ракета-носитель Союз-2.1б стартовала с космодрома Восточный. На его борту находятся 36 спутников OneWeb — космического интернет-провайдера.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f><a href="https://media.tproger.ru/uploads/2021/05/1-35.jpg"></a></p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Спустя какое-то время после запуска с заявлением выступил коммерческий директор компании в России Михаил Кайгородов. По его словам, уже в конце 2021 года OneWeb «сможет предоставлять услуги связи на территории России».</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Напомним, что изначально сегодняшний старт должен был случиться ещё вчера, 27 мая. Но из-за необходимости замены электрооборудования на ракете, запуск решили перенести на сегодня.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>OneWeb — британская компания, которая к концу 2022 года намерена развернуть группировку из 648 спутников. С их помощью провайдер планирует обеспечить широкополосным доступом к интернету пользователей по всей поверхности Земли.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Источник: <a href="https://t.me/bbbreaking/89749">Раньше всех. Ну почти.</a></p><!--]--><!--]-->',
  original:
    "https://tproger.ru/news/kosmicheskij-internet-oneweb-mozhet-zarabotat-v-rossii-do-konca-2021-goda/",
  id: 161672,
  link: "https://tproger.ru/news/kosmicheskij-internet-oneweb-mozhet-zarabotat-v-rossii-do-konca-2021-goda/",
  slug: "kosmicheskij-internet-oneweb-mozhet-zarabotat-v-rossii-do-konca-2021-goda",
};
