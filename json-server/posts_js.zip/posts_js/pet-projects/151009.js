module.exports = {
  title:
    "Разработчик скупил 300 эмодзи-доменов в Казахстане и сделал на их основе почтовый сервис",
  views: "4944",
  createdAt: "2021-03-11T14:02:09+00:00",
  img: "/images/tags-bell/tags-bell.png",
  type: ["Веб-разработка", "Pet-проекты", "Хобби"],
  comments: [
    "E-mail в 2021 году? Что такого умеет мыло, чего нет в мессенджерах?",
    "Alexey Ozerov, Децентрализованности нет. Это главная проблема мессенджеров. Чтобы с кем-то общаться, нужно чтобы человек был зарегистрирован в том же мессенджере, а по почте не важно, кто какой сервис использует. Ещё отсутствует поддержка HTML и скромное ограничение на длину сообщения – красиво оформленное сообщение не отправишь.\nУ мессенджеров своя ниша - быстрая отправка коротких сообщений, в то время как почта всё ещё используется для ведения деловой переписки и всяких там регистраций/уведомлений. Эти две вещи существуют параллельно не мешаю друг другу, каждая под свои задачи.",
  ],
  html: '<!--[--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Фулстек-разработчик Бэн Стоукс <a href="https://tinyprojects.dev/projects/mailoji">опубликовал</a> в своём блоге пост с рассказом о новом проекте. Девелопер скупил 300 доменных имён, состоящих из эмодзи, чтобы использовать их для необычного почтового сервиса.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Называется проект Mailoji. С его помощью любой желающий может зарегистрировать почтовый адрес с использованием одного из трёхсот эмодзи. Выглядит он так:</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f><a href="https://media.tproger.ru/uploads/2021/03/1-25.jpg"></a></p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Историю покупки доменов и раскрутки своего сервиса Стоукс описал в блоге. Если кратко, то сначала он загорелся идеей купить <code class=" language-none lazy-code">netflix.soy</code>, но в результате изучения сферы выяснил, что покупать можно и доменные имена, состоящие из эмодзи.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Пройдя через различные трудности (в том числе с доставкой электронного письма от необычного адреса), разработчик смог запустить почтовый сервис. А для того, чтобы минимизировать затраты и получить максимальное число эмодзи в своё распоряжение, девелопер воспользовался сегментом <code class=" language-none lazy-code">.kz</code>.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Попробовать Mailoji можно по <a href="https://mailoji.com/">ссылке</a>. Но обратите внимание — сервис платный и стоит 9,99 долларов (735 рублей) в год.</p><!--]--><!--[--><div class="tp-embed" data-type="embed" data-v-a1dfa206><span class="tp-embed-plug" data-v-a1dfa206></span></div><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Источник: <a href="https://tinyprojects.dev/projects/mailoji">TinyProjects</a></p><!--]--><!--]-->',
  original:
    "https://tproger.ru/news/razrabotchik-skupil-300-jemodzi-domenov-v-kazahstane-i-sdelal-na-ih-osnove-pochtovyj-servis/",
  id: 151009,
  link: "https://tproger.ru/news/razrabotchik-skupil-300-jemodzi-domenov-v-kazahstane-i-sdelal-na-ih-osnove-pochtovyj-servis/",
  slug: "razrabotchik-skupil-300-jemodzi-domenov-v-kazahstane-i-sdelal-na-ih-osnove-pochtovyj-servis",
};
