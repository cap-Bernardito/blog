module.exports = {
  title:
    "Inliner: VSCode-расширение для чтения и исправления кода без необходимости переключаться между файлами",
  views: "5570",
  createdAt: "2021-05-11T06:44:59+00:00",
  img: "/images/tags-bell/tags-bell.png",
  type: ["JavaScript", "Python", "JetBrains", "Pet-проекты", "YouTube"],
  comments: [
    "Vscode marketplace открытый и бесплатный. Зачем емейл когда гитхаб?",
    "Yurij Georgievich, Неосилятор",
    "Yurij Georgievich, Чтобы продавать имейлы, конечно же",
    "Тащат фичи из IDEA. И все равно VS Code далеко до нее...",
    "Не то чтобы что-то новое изобрели, но выглядит удобно.",
  ],
  html: '<!--[--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>На Reddit набирает популярность тред с новым расширением для VSCode. Проект, получивший название Inliner, позволяет исправлять код в сторонних файлах, не выходя из уже открытого.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Разработкой инструмента занимается Siddhant Jain — автор одноимённого YouTube-канала. По словам девелопера, на данный момент Inliner поддерживает лишь Python и JavaScript. Но в дальнейшем планируется добавление множества других языков.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f><a href="https://media.tproger.ru/uploads/2021/05/1-3.jpg"></a></p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Более того, автор пообещал выпустить такое же расширение и для остальных редакторов, в том числе выпущенных JetBrains.</p><!--]--><!--[--><h3 class="tp-content-subtitle tp-content-subtitle--h3" data-type="header3" data-v-75e770f1>Как работает Inliner?</h3><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Если пользователь хочет получить доступ к функции, находящейся в отдельном файле, ему достаточно кликнуть на её вызов в коде. Расширение откроет блок с ней в том же окне редактора, а затем сохранить внесённые изменения. </p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Более наглядно работу Inliner можно увидеть в видео:</p><!--]--><!--[--><div class="tp-embed" data-type="embed" data-v-a1dfa206><span class="tp-embed-plug" data-v-a1dfa206></span></div><!--]--><!--[--><h3 class="tp-content-subtitle tp-content-subtitle--h3" data-type="header3" data-v-75e770f1>Как скачать и установить расширение себе?</h3><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Пока что автор не опубликовал инструмент в магазине расширений VSCode. Вместо этого он предлагает пользователям оставить адрес электронной почты, перейдя по <a href="https://inliner.io/">ссылке</a>. На него Siddhant Jain в дальнейшем вышлет инструкцию для участия в раннем доступе.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Источник: <a href="https://www.reddit.com/r/programming/comments/n99kv1/inliner_pull_blocks_of_code_into_a_single_file/">Reddit</a></p><!--]--><!--]-->',
  original:
    "https://tproger.ru/news/inliner-vscode-rasshirenie-dlja-chtenija-i-ispravlenija-koda-bez-neobhodimosti-perekljuchatsja-mezhdu-fajlami/",
  id: 159666,
  link: "https://tproger.ru/news/inliner-vscode-rasshirenie-dlja-chtenija-i-ispravlenija-koda-bez-neobhodimosti-perekljuchatsja-mezhdu-fajlami/",
  slug: "inliner-vscode-rasshirenie-dlja-chtenija-i-ispravlenija-koda-bez-neobhodimosti-perekljuchatsja-mezhdu-fajlami",
};
