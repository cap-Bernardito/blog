module.exports = {
  title:
    "Google Project Starline: «голографический» видеочат с максимальным эффектом присутствия собеседника",
  views: "1578",
  createdAt: "2021-05-19T07:10:54+00:00",
  img: "/images/tags-bell/tags-bell.png",
  type: [
    "Конференции",
    "Google",
    "Нейронные сети",
    "Искусственный интеллект",
    "Pet-проекты",
  ],
  comments: [],
  html: '<!--[--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Накануне вечером прошло открытие конференции Google I/O 2021. На нём поисковый гигант показал много чего интересного: новейшие разработки в поиске и искусственном интеллекте, Android 12, новый «язык дизайна» Material You.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Но одним из самых интересных анонсов оказался Project Starline. Если говорить кратко, то это «голографический Zoom».</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f><a href="https://media.tproger.ru/uploads/2021/05/3-4.png"></a></p><!--]--><!--[--><h3 class="tp-content-subtitle tp-content-subtitle--h3" data-type="header3" data-v-75e770f1>Что такое Project Starline?</h3><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Это набор хардверных и программных технологий, с помощью которых пользователи могут общаться через голографическую видеосвязь.</p><!--]--><!--[--><blockquote class="tp-content-hint" fullwidth="true" data-type="hint" data-v-640486f3>Представьте, что смотрите сквозь своеобразное магическое окно. И через это окно вы видите другого человека: в натуральную величину и полноценном трёхмерном измерении. Вы можете максимально натуралистично общаться, жестикулировать, установить контакт.</blockquote><!--]--><!--[--><div class="tp-video" data-type="video" data-v-1d4b1aac><video class="tp-video__player" height="1182" width="1734" controls muted data-v-1d4b1aac></video></div><!--]--><!--[--><h3 class="tp-content-subtitle tp-content-subtitle--h3" data-type="header3" data-v-75e770f1>Как устроена технология?</h3><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Точных данных Google не опубликовала. Известно лишь, что техногигант объединил свои наработки в компьютерном зрении, машинном обучении, пространственном звуке и компрессии в реальном времени.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Вместе с тем компани разработала «революционный» дисплей, создающий ощущение объёма и глубины без необходимости использовать дополнительные очки или шлемы.</p><!--]--><!--[--><div class="tp-video" data-type="video" data-v-1d4b1aac><video class="tp-video__player" height="478" width="852" controls muted data-v-1d4b1aac></video></div><!--]--><!--[--><h3 class="tp-content-subtitle tp-content-subtitle--h3" data-type="header3" data-v-75e770f1>Как оформить заказ на Project Starline?</h3><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Пока что никак. Google установила наборы проекта в нескольких своих офисах. Но представители компании уже заявили, что видят будущее виртуального общения именно таким, каким его показывает Project Starline.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Также ИТ-гигант пообещал поделиться новыми подробностями о новинке до конца 2021 года.</p><!--]--><!--[--><div class="tp-embed" data-type="embed" data-v-a1dfa206><span class="tp-embed-plug" data-v-a1dfa206></span></div><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Источник: <a href="https://blog.google/technology/research/project-starline/">Блог Google</a></p><!--]--><!--]-->',
  original:
    "https://tproger.ru/news/google-predstavila-project-starline-golograficheskoe-zerkalo-dlja-videozvonkov/",
  id: 160560,
  link: "https://tproger.ru/news/google-predstavila-project-starline-golograficheskoe-zerkalo-dlja-videozvonkov/",
  slug: "google-predstavila-project-starline-golograficheskoe-zerkalo-dlja-videozvonkov",
};
