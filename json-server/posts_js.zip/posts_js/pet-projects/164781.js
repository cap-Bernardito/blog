module.exports = {
  title: "Free Dev Stuff — сборник бесплатных инструментов для разработчиков",
  views: "1907",
  createdAt: "2021-06-21T05:27:07+00:00",
  img: "/images/tags-bell/tags-bell.png",
  type: ["Веб-разработка", "Инструменты", "Pet-проекты", "dev"],
  comments: [],
  html: '<!--[--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>В последние годы тема пиратства становится всё менее актуальной. Онлайн-кинотеатры всё чаще используются для просмотра фильмов и сериалов, а у некогда единственно возможных платных приложений начали появляться достойные бесплатные аналоги.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f><a href="https://media.tproger.ru/uploads/2021/06/1-autoconverted-7.jpeg"></a></p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Именно такие инструменты для разработчиков были собраны на портале <a href="https://freestuff.dev/">Free Dev Stuff</a>. Здесь можно найти как достаточно популярные Notion и Visual Studio Code, так и более нишевые, наподобие Tawk.To.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Сами проекты представлены в виде списка. При этом по каждому из них есть небольшая справочная информация: какие именно ограничения для бесплатной версии, на каких платформах доступен и т.д:</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f><a href="https://media.tproger.ru/uploads/2021/06/Screenshot-2021-06-21-at-08.22.40.png"></a></p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Автор платформы оставил возможность предлагать свои проекты сторонним энтузиастам. Для этого достаточно создать новый файл, перейдя по <a href="https://github.com/hilmanski/freeStuffDev/new/main/content/stuff?value=%2B%2B%2B%0Adate%20%3D%20%22YYYY-MM-DDT00%3A00%3A00%2B00%3A00%22%0Atags%20%3D%20%5B%22tag%22%5D%0Atitle%3D%22Title%22%0Alink%20%3D%20%22https%3A%2F%2Flink%22%0Athumbnail%20%3D%20%22url_thumbnail%22%0Asnippet%3D%22Snippet%20of%20product%22%0A%2B%2B%2B%0ADetail%20what%27s%20free%20here..%0A">ссылке</a>. Если предложенный вами вариант окажется полезным, то его добавят в общий список.</p><!--]--><!--]-->',
  original:
    "https://tproger.ru/news/free-dev-stuff-sbornik-besplatnyh-instrumentov-dlja-razrabotchikov/",
  id: 164781,
  link: "https://tproger.ru/news/free-dev-stuff-sbornik-besplatnyh-instrumentov-dlja-razrabotchikov/",
  slug: "free-dev-stuff-sbornik-besplatnyh-instrumentov-dlja-razrabotchikov",
};
