module.exports = {
  title:
    "Представлена полностью настраиваемая клавиатура. Можно буквально собрать её с нуля",
  views: "889",
  createdAt: "2021-02-12T04:02:18+00:00",
  img: "/images/tags-bell/tags-bell.png",
  type: ["DIY", "Pet-проекты"],
  comments: [],
  html: '<!--[--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Компания System76, которая специализируется на производстве ноутбуков, ПК и серверов на Linux, <a href="https://github.com/system76/launch">опубликовала на GitHub проект Launch Configurable Keyboard</a>. Это клавиатура, которую пользователь может собрать сам и настроить под свои предпочтения. В открытый доступ выложены механические и электрические схемы, прошивки и программное обеспечение, используемое для управления.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Для производства предлагается использовать алюминий. Все порты и отверстия спроектированы так, чтобы замена клавиш и подключение кабелей были лёгкими и безопасными. Для увеличения угла наклона на 15 градусов используется съёмная планка, которую можно прикрепить с помощью магнитов. Предусмотрены дополнительные возможности для замены клавиш, переназначения управляющих кнопок и формирования индивидуальной раскладки.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Клавиатура подключается к компьютеру с помощью кабеля USB-C — USB-C или USB-C — USB-A. У самого устройства есть ещё два порта USB-C и два порта USB-A, соответствующих спецификации USB 3.2 Gen 2 со скоростью до 10 Гбит/с. Каждая клавиша оснащена собственным светодиодом, которым можно управлять отдельно через прошивку.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f><a href="https://media.tproger.ru/uploads/2021/02/launch-chassis.jpg"></a><a href="https://media.tproger.ru/uploads/2021/02/launch-pcb.jpg"></a></p><!--]--><!--]-->',
  original:
    "https://tproger.ru/news/predstavlena-polnostju-nastraivaemaja-klaviatura-mozhno-bukvalno-sobrat-ejo-s-nulja/",
  id: 147124,
  link: "https://tproger.ru/news/predstavlena-polnostju-nastraivaemaja-klaviatura-mozhno-bukvalno-sobrat-ejo-s-nulja/",
  slug: "predstavlena-polnostju-nastraivaemaja-klaviatura-mozhno-bukvalno-sobrat-ejo-s-nulja",
};
