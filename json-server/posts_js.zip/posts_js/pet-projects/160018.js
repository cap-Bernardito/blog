module.exports = {
  title:
    "Видео: нейрочип «научил» парализованного человека писать текст силой мысли",
  views: "1041",
  createdAt: "2021-05-13T06:15:24+00:00",
  img: "/images/tags-bell/tags-bell.png",
  type: ["Pet-проекты", "Нейрочип"],
  comments: [],
  html: '<!--[--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Группа исследователей научила парализованного человека писать текст одной лишь силой мысли. Для этого учёные вживили в его мозг нейрочип, который «считывал» мозговую активность участника эксперимента.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>При этом мужчина пытался именно что писать текст, представляя как он это делает своими руками. А уже специальный алгоритм обрабатывал мозговые импульсы. </p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f><a href="https://media.tproger.ru/uploads/2021/05/1-6.jpg"></a></p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Новый метод позволил установить мировой рекорд по скорости печати силой мысли — 90 символов в минуту. Это примерно в два раза быстрее, чем при печати на клавиатуре с помощью воображения, и немногим меньше скорости набора текста на смартфоне обычными пользователями.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Учёные отметили, что их алгоритм смог показать 99%-точность набора в оффлайн-режиме с включённой автокоррекцией.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Видео с демонстрацией эксперимента:</p><!--]--><!--[--><div class="tp-embed" data-type="embed" data-v-a1dfa206><span class="tp-embed-plug" data-v-a1dfa206></span></div><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Напомним, что несколько недель назад Neuralink Илона Маска <a href="https://tproger.ru/news/video-neuralink-ilona-maska-pokazala-kak-9-letnjaja-obezjana-igraet-v-videoigru-siloj-mysli/">показала</a> свой эксперимент. В нём инженеры компании вживили чип в мозг обезьяны, а после научили её играть в Pong силой мысли.</p><!--]--><!--[--><div class="tp-embed" data-type="embed" data-v-a1dfa206><span class="tp-embed-plug" data-v-a1dfa206></span></div><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Источник: <a href="https://arstechnica.com/science/2021/05/neural-implant-lets-paralyzed-person-type-by-imagining-writing/">Ars Technica</a></p><!--]--><!--]-->',
  original:
    "https://tproger.ru/news/video-nejrochip-nauchil-paralizovannogo-cheloveka-pisat-tekst-siloj-mysli/",
  id: 160018,
  link: "https://tproger.ru/news/video-nejrochip-nauchil-paralizovannogo-cheloveka-pisat-tekst-siloj-mysli/",
  slug: "video-nejrochip-nauchil-paralizovannogo-cheloveka-pisat-tekst-siloj-mysli",
};
