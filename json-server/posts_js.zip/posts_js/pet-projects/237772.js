module.exports = {
  title:
    "Что вы делали на этой неделе? Пост хвастовства за 27 февраля — 3 марта",
  views: "3274",
  createdAt: "2023-03-03T12:34:47+00:00",
  img: "https://media.giphy.com/media/ThrM4jEi2lBxd7X2yz/giphy.gif",
  type: ["Работа", "Pet-проекты"],
  comments: [
    "Сделал авторизацию на spring security в своём пет проекте для работы с ChatGPT ), настроил ci/cd для бэка, сделал странички входа/профиля в СПАшке. Посмотрел что нового у других велосипедов )",
    "Сделал со своим ментором 2 приложения под iOS, поработав с парсингом данных, локализацией приложения, продолжаю развиваться в iOS-Разработке, попутно обучаясь в универе.Пока ничего сверхъестественного, но дальше - больше????",
    "vadeek, Где ментора нашли?",
    "Дописал статью про минимальную стоимость банковского приложения в облаке. Характеристики скорости работы.Построил архитектуру высокоскоростного сканера транзакций из mempool блокчейна.Продолжил развитие проекта арбитражного бота для CEX/DEX бирж.",
    "sandwars, Крутой!",
    "sandwars, А шо там в мемпуле надо скоростного делать? Ты же просто вызываешь один и тот же метод у нескольких пулов ликвидности, не?",
  ],
  html: '<!--[--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Предлагаем делиться в комментариях под этой записью, над чем вы работали на этой неделе, ведь нет ничего интереснее, чем задачи коллег! Вот, чем вы занимались <a href="https://tproger.ru/articles/chto-vy-delali-na-jetoj-nedele-post-ljogkogo-hvastovstva-za-20-24-fevralja/">на прошлой неделе</a>.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Не важно, разработчик вы или тестировщик, деврел или эйчар. Расскажите, какие задачи вы героически решили, и делитесь успехами.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Кидайте всё, чем хочется похвастаться: текст, скриншоты кода и даже ссылочки на видео.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Не забывайте про NDA: не указывайте названия компании или деликатные частности.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Итак, чем вы похвастаетесь на этой неделе?</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f><u is="tp-badge" class="tp-badge tp-badge--first-variant" data-color="firstVariant">Внимание</u> Это — зона взаимного уважения, понимания и нулевого токсика. Похвала и помощь горячо приветствуются. ?</p><!--]--><!--[--><div class="tp-content-image" title stretched="false" withbackground="false" withborder="false" data-type="image" data-v-541f8e6a><a class="tp-content-image__image-viewer-item" data-pswp-src="https://media.giphy.com/media/ThrM4jEi2lBxd7X2yz/giphy.gif" data-pswp-width="0" data-pswp-height="0" data-v-541f8e6a><div class="tp-image" style="border-radius:8px;" data-v-d15050b5 data-v-541f8e6a><img class="tp-image__image" src="https://media.giphy.com/media/ThrM4jEi2lBxd7X2yz/giphy.gif" srcset sizes alt style="object-fit:fill;aspect-ratio:auto;object-position:50% 50%;" loading="auto" decoding="async" data-v-d15050b5></div></a><!----></div><!--]--><!--]-->',
  original:
    "https://tproger.ru/articles/chto-vy-delali-na-jetoj-nedele-post-hvastovstva-za-27-fevralja-3-marta/",
  id: 237772,
  link: "https://tproger.ru/articles/chto-vy-delali-na-jetoj-nedele-post-hvastovstva-za-27-fevralja-3-marta/",
  slug: "chto-vy-delali-na-jetoj-nedele-post-hvastovstva-za-27-fevralja-3-marta",
};
