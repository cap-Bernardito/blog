module.exports = {
  title:
    "А(x56): шуточный сервис для удлинения URL-адресов с возможностью автоматизации",
  views: "7118",
  createdAt: "2021-05-17T06:59:34+00:00",
  img: "/images/tags-bell/tags-bell.png",
  type: ["Интернет", "Сервисы", "Pet-проекты"],
  comments: [
    "https://t.me/+uxvIbfdbeHY0MDcy",
    "ну хоть бы ссылку дали...",
    "shewaeger, Вот: https://aaa.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.com/",
    "Алексей Михайлишин, Вчера не мог адрес найти",
    "Вот бы все новости были такие, а не о том, что опять что-то заблокировали.",
  ],
  html: '<!--[--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>«Устали от слишком коротких URL-адресов? Не стоит больше беспокоиться, так как теперь <a href="https://aaa.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.com/">aaa.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.com</a> готов прикрыть вас» — такими словами встречает пользователей новый сервис A(x56). Его единственной задачей является удлинение веб-адресов.</p><!--]--><!--[--><h3 class="tp-content-subtitle tp-content-subtitle--h3" data-type="header3" data-v-75e770f1>Как удлинить URL?</h3><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Для этого надо вбить в поле «Original URL» желаемый адрес. Например, введя https://tproger.ru/, мы получили от сервиса в несколько раз более длинный адрес:</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f><a href="https://media.tproger.ru/uploads/2021/05/1-14.jpg"></a></p><!--]--><!--[--><h3 class="tp-content-subtitle tp-content-subtitle--h3" data-type="header3" data-v-75e770f1>А что там по автоматизации?</h3><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>На сайте А(x56) есть отдельная страница, на которой разработчики рассказали о способах внедрения сервиса в свой проект. Там же можно найти способ использования API сервиса.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Что интересно, автор платформы даже дал ссылку на дашборд проекта. В нём можно увидеть разную интересную информацию. В том числе об источниках визита на сервис, количестве посетителей и т.д:</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f><a href="https://media.tproger.ru/uploads/2021/05/Screenshot-2021-05-17-at-09.37.28-3.png"></a></p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Источник: <a href="https://aaa.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.com/">А(x56)</a></p><!--]--><!--]-->',
  original:
    "https://tproger.ru/news/a-x56-shutochnyj-servis-dlja-udlinenija-url-adresov-s-vozmozhnostju-avtomatizacii/",
  id: 160251,
  link: "https://tproger.ru/news/a-x56-shutochnyj-servis-dlja-udlinenija-url-adresov-s-vozmozhnostju-avtomatizacii/",
  slug: "a-x56-shutochnyj-servis-dlja-udlinenija-url-adresov-s-vozmozhnostju-avtomatizacii",
};
