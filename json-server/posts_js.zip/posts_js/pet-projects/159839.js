module.exports = {
  title:
    "IBM создала ИИ для перевода кода с одного языка программирования на другой",
  views: "2998",
  createdAt: "2021-05-12T07:02:16+00:00",
  img: "/images/tags-bell/tags-bell.png",
  type: [
    "Java",
    "C++",
    "Python",
    "Нейронные сети",
    "Искусственный интеллект",
    "IBM",
    "Pet-проекты",
  ],
  comments: [
    "Удивляюсь уже не раз какой талант у тупрогера испортить любую статью которую они перепечатывают. Это возмутительно!",
    "Ау",
  ],
  html: '<!--[--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>В рамках конференции Think 2021 представители IBM объявили о свежем проекте — IBM CodeNet. Основной для него стал искусственный интеллект (ИИ), способный переводить код с одного языка программирования на другой.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Новая разработка может быть полезна при «переносе» старых legacy-проектов на более свежие рельсы. Например, девелоперы смогут взять устаревший код, часто встречающийся в банковской и государственной сферах, и перевести его на условный Java или Python.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f><a href="https://media.tproger.ru/uploads/2021/05/1-5-scaled.jpg"></a></p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Нам нужен свой ImageNet, который может исследовать инновационные идеи и отражать их в различных алгоритмах, — отметили исследователи. — CodeNet — это, по сути, ImageNet для компьютеров. IBM</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>В IBM рассказали, что модель обучалась на 14 млн фрагментах кода и 500 млн строк на более чем 50 старых и новых языках. В качестве примера были приведены такие «мамонты» как COBOL и FORTRAN, а также вполне активные варианты — Java, C++ и Python.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>И хоть на данный момент нет точной информации о релизе CodeNet, представители IBM уже заявили, что предоставят доступ к проекту всем желающим.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Источник: <a href="https://www.engadget.com/ibm-codenet-dataset-can-teach-ai-to-translate-computer-languages-020052618.html">Engadget</a></p><!--]--><!--]-->',
  original:
    "https://tproger.ru/news/ibm-sozdala-ii-dlja-perevoda-koda-s-odnogo-jazyka-programmirovanija-na-drugoj/",
  id: 159839,
  link: "https://tproger.ru/news/ibm-sozdala-ii-dlja-perevoda-koda-s-odnogo-jazyka-programmirovanija-na-drugoj/",
  slug: "ibm-sozdala-ii-dlja-perevoda-koda-s-odnogo-jazyka-programmirovanija-na-drugoj",
};
