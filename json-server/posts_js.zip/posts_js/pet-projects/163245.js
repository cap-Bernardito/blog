module.exports = {
  title:
    "В Китае создали аналог робопса от Boston Dynamics, но почти в 30 раз дешевле оригинала",
  views: "2481",
  createdAt: "2021-06-10T16:09:25+00:00",
  img: "/images/tags-bell/tags-bell.png",
  type: ["Роботы", "Искусственный интеллект", "Pet-проекты", "YouTube"],
  comments: [
    'Нафига, а главное зачем? Бутылку таскать за собой? Да и та рискует выпасть из ненадежного крепления. Это конечно действительно "важное" вложение денег. Ни о каких эмоциях как от реального питомца конечно и речи быть не может. Выглядит стрёмно и футуристично. Практической пользы 0. Даже интересно кто и зачем это купит.',
    "Илья, ну от Boston Dynamics же он кому-то нужен, значит и у этих найдется целевая аудитория)",
    "Илья, Тоже думаю, что своя аудитория будет. Тем более цена по сравнению с Boston Dynamics смешная. \n\nОстаётся только порадоваться за людей, у которых есть от 200 до 600к на такие развлечения:)",
    "Презентация так себе.",
  ],
  html: '<!--[--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Последние лет 10 ролики Boston Dynamic с их робопсами становятся вирусными. Из-за этого подобные девайсы ассоциируются исключительно с американской компанией.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Но, как оказалось, подобных роботизированных компаньонов создают не только в её стенах. Так, например, Unitree Robotics из Китая представила своё новое творение — робопса Unitree Go1.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f><a href="https://media.tproger.ru/uploads/2021/06/1-13.jpg"></a></p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Всего компания создала три версии машины: Go1 Air за 2,7 тыс долларов (194 тыс рублей), Go1 за 3,5 тыс долларов (266 тыс рублей) и Go1 Edu за 8,5 тыс долларов (611 тысяч рублей). Все они весят 12 кг. При этом к покупке пока что доступна лишь базовая.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Для сравнения, Spot от Boston Dynamics продаётся за 74,5 тыс долларов (5,4 млн рублей) — это в 27,6 раз дороже базовой версии Unitree Go1.</p><!--]--><!--[--><div class="tp-video" data-type="video" data-v-1d4b1aac><video class="tp-video__player" height="720" width="1280" controls muted data-v-1d4b1aac></video></div><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Сообщается, что китайский робопёс в более дорогих модификациях способен разгоняться до 17 км/ч. При этом об автономности устройства нет точной информации.</p><!--]--><!--[--><!----><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Компания-разработчик заявляет о том, что робот позиционируется как «спутник на весь день». Но журналисты The Verge <a href="https://www.theverge.com/2021/6/10/22527413/tiny-robot-dog-unitree-robotics-go1">высказали</a> своё сомнение в этом, напомнив, что тот же Spot живёт от одного заряда до 1,5 часов.</p><!--]--><!--[--><div class="tp-embed" data-type="embed" data-v-a1dfa206><span class="tp-embed-plug" data-v-a1dfa206></span></div><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Источник: <a href="https://www.theverge.com/2021/6/10/22527413/tiny-robot-dog-unitree-robotics-go1">The Verge</a></p><!--]--><!--]-->',
  original:
    "https://tproger.ru/news/v-kitae-sozdali-analog-robopsa-ot-boston-dynamics-no-pochti-v-30-raz-deshevle-originala/",
  id: 163245,
  link: "https://tproger.ru/news/v-kitae-sozdali-analog-robopsa-ot-boston-dynamics-no-pochti-v-30-raz-deshevle-originala/",
  slug: "v-kitae-sozdali-analog-robopsa-ot-boston-dynamics-no-pochti-v-30-raz-deshevle-originala",
};
