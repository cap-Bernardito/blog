module.exports = {
  title: "Пишем приложение на Electron. Часть 1. Знакомство с Electron",
  views: "2670",
  createdAt: "2021-09-01T10:28:55+00:00",
  img: "/images/tags-bell/tags-bell.png",
  type: ["JavaScript", "Pet-проекты", "Пост пользователя"],
  comments: [],
  html: '<!--[--><!--[--><div class="tp-embed" preview="https://i.ytimg.com/vi_webp/Q8qePKtod3U/maxresdefault.webp" videoid="Q8qePKtod3U" type="youtube" data-type="embed" data-v-a1dfa206><span class="tp-embed-plug" data-v-a1dfa206></span></div><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Это не уроки. У меня родилась идея приложения, которое я хочу реализовать. Решил сделать это вместе с вами. Затем появилась идея интеграции Electron-приложения с приложением на Go. Интересно? Вот мне тоже!</p><!--]--><!--[--><h2 class="tp-content-subtitle tp-content-subtitle--h2" data-type="header2" data-v-75e770f1>Идея приложения</h2><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Вы хотите поднять локально PostgreSQL или MongoDB, или RabbitMQ, или nginx, или ещё что-то. Но открывать терминал, искать Docker-образ, настраивать его — лень. Что уж говорить о решении с виртуальной машиной и ручной установкой продукта.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Я хочу сделать десктопное приложение, которое позволит быстро запустить и развернуть любой продукт, без единой строчки конфигурации в простом режиме.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Конечно, можно предусмотреть продвинутый режим, в котором будет возможность отредактировать конфигурацию docker’a или docker-compose файла. Но основная мысль в том, чтобы развернуть PostgreSQL, не исправляя ни единой строчки в конфигурации, а просто нажав 2-3 кнопки в интерфейсе.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Подробности и мои мучения в видео.</p><!--]--><!--]-->',
  original:
    "https://tproger.ru/video/pishem-prilozhenie-na-electron-chast-1-znakomstvo-s-electron/",
  id: 178658,
  link: "https://tproger.ru/video/pishem-prilozhenie-na-electron-chast-1-znakomstvo-s-electron/",
  slug: "pishem-prilozhenie-na-electron-chast-1-znakomstvo-s-electron",
};
