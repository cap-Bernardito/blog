module.exports = {
  title:
    "Видео: студенты киношколы сняли короткометражки по сценариям искусственного интеллекта",
  views: "643",
  createdAt: "2021-04-07T11:07:09+00:00",
  img: "/images/tags-bell/tags-bell.png",
  type: [
    "Искусственный интеллект",
    "Фильмы",
    "OpenAI",
    "Pet-проекты",
    "YouTube",
  ],
  comments: [],
  html: '<!--[--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Два студента калифорнийской киношколы — Илай Вайс и Джейкоб Ваус — используют нейросеть GPT-3 для генерации небольших сценариев. А уже на их основе они снимают короткометражные фильмы.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f><a href="https://media.tproger.ru/uploads/2021/04/1-15.jpg"></a></p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Например, их последняя работа под названием «Свидание» рассказывает о достаточно странной паре. Во время ужина парень занимается гипнозом девушки, чтобы она смогла приручить своё внутреннее животное. Но когда они оба пробуждаются, то к ним приходит осознание того, что вокруг всё нереально. Также они понимают, что они на самом деле актёры, снимающиеся в фильме:</p><!--]--><!--[--><div class="tp-embed" data-type="embed" data-v-a1dfa206><span class="tp-embed-plug" data-v-a1dfa206></span></div><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Т.к. разработчики из OpenAI всё ещё отказываются сделать GPT-3 общедоступным, Вайс и Ваус используют программу Shortly AI. Они дают ей завязку истории, которую инструмент самостоятельно развивает до чего-то более-менее законченного.</p><!--]--><!--[--><blockquote class="tp-content-hint" fullwidth="true" data-type="hint" data-v-640486f3>Мы не редактируем сценарии, но создаём несколько версий. Обычно мы пишем первую половину страницы сценария, а потом генерируем несколько страниц. Мы повторяем процедуру несколько раз и выбираем наиболее развлекательный сценарий.</blockquote><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Для публикации своих работ, студенты создали YouTube-канал Calamity AI. На нём, помимо короткометражек, они также выкладывают прочие работы с использованием GPT-3. Об одном из них мы <a href="https://tproger.ru/news/ai-made-song-about-zuckerberg/">рассказывали</a> ранее.</p><!--]--><!--[--><div class="tp-embed" data-type="embed" data-v-a1dfa206><span class="tp-embed-plug" data-v-a1dfa206></span></div><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Источник: TJ</p><!--]--><!--]-->',
  original:
    "https://tproger.ru/news/video-studenty-kinoshkoly-snjali-korotkometrazhki-po-scenarijam-iskusstvennogo-intellekta/",
  id: 154617,
  link: "https://tproger.ru/news/video-studenty-kinoshkoly-snjali-korotkometrazhki-po-scenarijam-iskusstvennogo-intellekta/",
  slug: "video-studenty-kinoshkoly-snjali-korotkometrazhki-po-scenarijam-iskusstvennogo-intellekta",
};
