module.exports = {
  title:
    "Хостинг «Маклауд» нанял вебкам-модель для проведения рекламных трансляций",
  views: "3796",
  createdAt: "2021-05-24T16:41:49+00:00",
  img: "/images/tags-bell/tags-bell.png",
  type: ["Интернет", "Pet-проекты", "YouTube", "Сервер"],
  comments: [],
  html: '<!--[--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>В сети появилась информация о необычной рекламной кампании от маркетологов «Маклауд». Компания, занимающаяся хостингом, сделала своим амбассадором Аню — инструктора по йоге и вебкам-модель.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f><a href="https://media.tproger.ru/uploads/2021/05/2_1-1.jpg"></a></p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Раз в неделю она будет проводить онлайн-трансляции, во время которых девушка планирует «брать по одной задаче (например, настроить SSL) и учиться делать это прямо во время стрима». При каждом успешном решении задачи, она намерена снимать по одной «детали» одежды.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>У Ани будет несколько площадок присутствия, в том числе YouTube и Onlyfans. Во время стримов вебкам-модель будет одета в фирменную футболку «Маклауд» с логотипом компании. </p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f><a href="https://media.tproger.ru/uploads/2021/05/1_1-3.jpg"></a></p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Представители хостинг-провайдера рассказали, что они не оплачивают трансляции девушки. Они лишь высылают ей мерч, консультируют в обучении и предоставляет техподдержку, сообщает vc.ru. При этом в будущем в «Маклауд» планируют собрать полноценный плейлист с туториалами на основе стримов Ани.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Источник: <a href="https://vc.ru/marketing/250083-hosting-maklaud-dogovorilsya-s-vebkam-modelyu-o-reklamnyh-strimah">vc.ru</a></p><!--]--><!--]-->',
  original:
    "https://tproger.ru/news/hosting-maklaud-nanjal-vebkam-model-dlja-provedenija-reklamnyh-transljacij/",
  id: 161158,
  link: "https://tproger.ru/news/hosting-maklaud-nanjal-vebkam-model-dlja-provedenija-reklamnyh-transljacij/",
  slug: "hosting-maklaud-nanjal-vebkam-model-dlja-provedenija-reklamnyh-transljacij",
};
