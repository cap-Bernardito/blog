module.exports = {
  title:
    "Cloudflare запустила DOOM с мультиплеером прямо в браузере при помощи воркеров",
  views: "2005",
  createdAt: "2021-05-19T11:10:57+00:00",
  img: "/images/tags-bell/tags-bell.png",
  type: [
    "Веб-разработка",
    "Облачные технологии",
    "Cloudflare",
    "Pet-проекты",
    "Игра",
  ],
  comments: [
    '"Решили её просто — добавив функцию emscripten_set_main_loop()"\nНе очень понял, просто поменяли имя функции и что-то заработало?',
  ],
  html: '<!--[--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Портирование DOOM на разные платформы — это своеобразное соревнование. Легендарный шутер уже запускали на калькуляторах, часах и даже тесте на беременность.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Но разработчики из Cloudflare опубликовали пост, в котором сообщили о <a href="https://silentspacemarine.com/">свежем порте</a>. Они запустили творение id Software прямо в браузере, используя для этого воркеры.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f><a href="https://media.tproger.ru/uploads/2021/05/1-13.png"></a></p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>А для того, чтобы показать скорость работы технологии, разработчики из Cloudflare добавили в свой порт мультиплеерный режим на несколько игроков.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f><a href="https://media.tproger.ru/uploads/2021/05/2-8.png"></a></p><!--]--><!--[--><h3 class="tp-content-subtitle tp-content-subtitle--h3" data-type="header3" data-v-75e770f1>С какими проблемами столкнулись разработчики при переносе игры?</h3><!--]--><!--[--><ul class="tp-content-list" style="" data-type="list" data-v-705dc74d><!--[--><li class="tp-content-list__item" data-v-705dc74d><b>В веб-страницах невозможно запустить цикл main().</b> Решили её просто — заменив цикл на функцию <a href="https://emscripten.org/docs/api_reference/emscripten.h.html#c.emscripten_set_main_loop">emscripten_set_main_loop()</a>.</li><li class="tp-content-list__item" data-v-705dc74d><b>Использование в сетевом коде игры UDP-протокола.</b> В итоге разработчики написали новый сетевой модуль Chocolate Doom. С его помощью они использовали протокол TCP и WebSockets вместо UDP.</li><!--]--></ul><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>О полном процессе переноса DOOM на рельсы воркеров можно почитать в блоге Cloudflare. Там команда, занимавшаяся портированием, максимально подробно расписала весь процесс.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f><a href="https://media.tproger.ru/uploads/2021/05/3-5.png"></a></p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Отметим, что Cloudflare Workers — очень удобный инструмент. Но у него есть и свои недостатки. Главный из них — вендор лок.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>То есть разработчики, использующие воркеры компании, будут вынуждены постоянно платить именно Cloudflare. Просто потому что их инструмент не стандартизирован. К тому же есть определённые сложности с переносом своего проекта на сторонние воркеры.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Источник: Блог Cloudflare</p><!--]--><!--]-->',
  original:
    "https://tproger.ru/news/cloudflare-zapustila-doom-s-multipleerom-prjamo-v-brauzere-pri-pomoshhi-vorkerov/",
  id: 160588,
  link: "https://tproger.ru/news/cloudflare-zapustila-doom-s-multipleerom-prjamo-v-brauzere-pri-pomoshhi-vorkerov/",
  slug: "cloudflare-zapustila-doom-s-multipleerom-prjamo-v-brauzere-pri-pomoshhi-vorkerov",
};
