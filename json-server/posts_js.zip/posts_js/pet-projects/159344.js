module.exports = {
  title:
    "Нейросеть «научила» киноактёров правдоподобно говорить на иностранном языке",
  views: "1777",
  createdAt: "2021-05-07T09:49:43+00:00",
  img: "/images/tags-bell/tags-bell.png",
  type: ["Нейронные сети", "Искусственный интеллект", "Pet-проекты"],
  comments: ["Выглядит очень круто, конечно."],
  html: '<!--[--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Компания Flawless представила новый инструмент — TrueSync. С его помощью будущие киноделы смогут синтезировать движения губ и мышц лица актёров для перевода фильмов на разные языки. </p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f><a href="https://media.tproger.ru/uploads/2021/05/1-2.jpg"></a></p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Сейчас авторы дубляжа вынуждены подстраивать переведённые реплики под длину оригинала. При этом даже в таком случае внимательный зритель может заметить, что услышанные им слова не совпадают с тем, что сказал сам актёр.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>С помощью TrueSync эта проблема будет решена. Технология заменяет оригинальное лицо на его deepfake-версию. Она сохраняет изначальную актёрскую игру, но при этом мимика меняется таким образом, что начинает соответствовать дубляжу.</p><!--]--><!--[--><div class="tp-embed" data-type="embed" data-v-a1dfa206><span class="tp-embed-plug" data-v-a1dfa206></span></div><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Представители Flawless не раскрыли цену использования её разработки. Но для всех интересующихся они предусмотрительно оставили <a href="https://www.flawlessai.com/contact">форму для связи</a>.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Источник: <a href="https://gizmodo.com/deepfake-lips-are-coming-to-dubbed-films-1846840191">Gizmodo</a></p><!--]--><!--]-->',
  original:
    "https://tproger.ru/news/nejroset-nauchila-kinoaktjorov-pravdopodobno-govorit-na-inostrannom-jazyke/",
  id: 159344,
  link: "https://tproger.ru/news/nejroset-nauchila-kinoaktjorov-pravdopodobno-govorit-na-inostrannom-jazyke/",
  slug: "nejroset-nauchila-kinoaktjorov-pravdopodobno-govorit-na-inostrannom-jazyke",
};
