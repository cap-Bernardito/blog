module.exports = {
  title:
    "Find Starlink: сервис, показывающий дату пролёта спутников Starlink над вашим городом",
  views: "3556",
  createdAt: "2021-05-31T12:25:50+00:00",
  img: "/images/tags-bell/tags-bell.png",
  type: ["Интернет", "Pet-проекты", "Илон Маск", "Космос"],
  comments: [],
  html: '<!--[--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Компания SpaceX Илона Маска продолжает запускать в космос всё новые спутники Starlink. И если сейчас их насчитывается около 1,5 тыс, то уже к 2027 году это число должно вырасти до 42 тыс штук.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>В последнее время в сети начало появляться множество фото пролетающих в ночном небе спутников Starlink. Для того, чтобы сделать процесс легче, анонимный разработчик создал сервис <a href="https://findstarlink.com/">Find Starlink</a> — сайт, показывающий, когда лучше всего выискивать аппараты SpaceX в небе над вашим городе.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f><a href="https://media.tproger.ru/uploads/2021/05/1-16.png"></a></p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Работает платформа достаточно просто. Пользователь либо выбирает из списка уже заданных создателем городов, либо вводит свои координаты. После этого Find Starlink показывает, когда именно в ближайшие 5 дней будет наилучшая видимость спутников, а в какие средняя и «не очень».</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Автор проекта отдельно отмечает, что «наилучшие результаты показываются в течение 4-5 дней после выхода новой группы спутников в космос». Связано это с тем, что уже спустя неделю они меньше отражают свет, из-за чего их гораздо сложнее отследить.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Источник: <a href="https://www.businessinsider.com/how-to-use-find-starlink-satellites-spacex-website-elon-musk-2021-5">Business Insider</a></p><!--]--><!--]-->',
  original:
    "https://tproger.ru/news/find-starlink-servis-pokazyvajushhij-datu-proljota-sputnikov-starlink-nad-vashim-gorodom/",
  id: 161981,
  link: "https://tproger.ru/news/find-starlink-servis-pokazyvajushhij-datu-proljota-sputnikov-starlink-nad-vashim-gorodom/",
  slug: "find-starlink-servis-pokazyvajushhij-datu-proljota-sputnikov-starlink-nad-vashim-gorodom",
};
