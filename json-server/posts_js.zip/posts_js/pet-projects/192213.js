module.exports = {
  title: "5 проектов на Codepen ко Дню святого Валентина",
  views: "4434",
  createdAt: "2022-02-14T12:19:46+00:00",
  img: "/images/tags-bell/tags-bell.png",
  type: [
    "JavaScript",
    "Веб-разработка",
    "CSS",
    "HTML",
    "Веб-дизайн",
    "Pet-проекты",
  ],
  comments: [],
  html: '<!--[--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Если вы из тех, кто любит добавлять на сайт анимированный снег, гирлянды и прочие праздничные атрибуты, эта подборка для вас. Ко Дню влюблённых мы подготовили пять интересных пенов, которые могут оказаться полезны в оформлении вашего веб-приложения.</p><!--]--><!--[--><h2 class="tp-content-subtitle tp-content-subtitle--h2" data-type="header2" data-v-75e770f1>Загрузка в форме сердца</h2><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Интересный способ тематически оформить процесс загрузки. Проект написан на HTML и CSS без использования JavaScript. При этом для своего сайта можно выбрать один из двух представленных вариантов: пульсация или изменение положения сердца.</p><!--]--><!--[--><div class="tp-embed" data-type="embed" data-v-a1dfa206><span class="tp-embed-plug" data-v-a1dfa206></span></div><!--]--><!--[--><h2 class="tp-content-subtitle tp-content-subtitle--h2" data-type="header2" data-v-75e770f1>Навигация</h2><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Навигационное меню, выполненное в розовых цветах и соответствующем оформлении. Здесь уже не обошлось без JavaScript.</p><!--]--><!--[--><div class="tp-embed" data-type="embed" data-v-a1dfa206><span class="tp-embed-plug" data-v-a1dfa206></span></div><!--]--><!--[--><h2 class="tp-content-subtitle tp-content-subtitle--h2" data-type="header2" data-v-75e770f1>Создание своей открытки</h2><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Это готовая анимация, в которую можно вписать текст для интро и аутро. Таким образом появляется возможность написать о своих чувствах конкретному человеку, скопировать ссылку на пен с изменённым текстом и отправить адресату. Кириллица поддерживается, но шрифт при этом становится стандартным.</p><!--]--><!--[--><div class="tp-embed" data-type="embed" data-v-a1dfa206><span class="tp-embed-plug" data-v-a1dfa206></span></div><!--]--><!--[--><h2 class="tp-content-subtitle tp-content-subtitle--h2" data-type="header2" data-v-75e770f1>След из сердец за курсором</h2><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Сердца двигаются за курсором и быстро исчезают, поэтому никаких неудобств для пользователя не создают. При желании всегда можно уменьшить размер и количество сердечек. Проект выполнен на чистом JavaScript: скрипт размещён в HTML-блоке.</p><!--]--><!--[--><div class="tp-embed" data-type="embed" data-v-a1dfa206><span class="tp-embed-plug" data-v-a1dfa206></span></div><!--]--><!--[--><h2 class="tp-content-subtitle tp-content-subtitle--h2" data-type="header2" data-v-75e770f1>Валентинка</h2><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Очень забавная айтишная валентинка для тех, кто знает песню Стиви Уандера «I just called to say I love you». Просто кликните по надписи и наслаждайтесь музыкой ?</p><!--]--><!--[--><div class="tp-embed" data-type="embed" data-v-a1dfa206><span class="tp-embed-plug" data-v-a1dfa206></span></div><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Кстати, если хотите признаться в любви оригинально, сделайте это как программист: держите <a href="https://tproger.ru/translations/valentine-day-puzzle/">романтическую историю с головоломкой</a>.</p><!--]--><!--]-->',
  original:
    "https://tproger.ru/articles/5-proektov-na-codepen-ko-dnju-svjatogo-valentina/",
  id: 192213,
  link: "https://tproger.ru/articles/5-proektov-na-codepen-ko-dnju-svjatogo-valentina/",
  slug: "5-proektov-na-codepen-ko-dnju-svjatogo-valentina",
};
