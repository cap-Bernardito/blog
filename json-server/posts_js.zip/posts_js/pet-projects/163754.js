module.exports = {
  title: "Видео: DOOM запустили на лампе ИКЕА с 108 КБ оперативной памяти",
  views: "2851",
  createdAt: "2021-06-15T06:46:42+00:00",
  img: "/images/tags-bell/tags-bell.png",
  type: ["GitHub", "Pet-проекты", "YouTube", "ARM", "Игра"],
  comments: [
    "https://www.reddit.com/r/itrunsdoom/comments/nys0bv/comment/h1tnx4z?context=3\nСудя по посту на Reddit, IKEA не одобрила сего действа(",
    "Может быть, стоит указать, что видео не работает до ссылки на него, а не после? Не сразу сообразил, что не так.\n\nПо теме: похоже, что автор только проц использовал от лампы, не вижу тут какого-то достижения. Но звучит круто, конечно.",
    "Не работает ни видео, ни ссылка на репу",
    "Андрей Симаранов, Добавил ссылку на кэш Google.",
  ],
  html: '<!--[--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f><i>UPD</i>: Спустя менее часа видео и информация о проекте были удалены из сети. В том числе с сайта next-hack. На данный момент доступ к материалу можно получить лишь через <a href="https://webcache.googleusercontent.com/search?q=cache:mZbvh_tQ42MJ:https://next-hack.com/index.php/2021/06/12/lets-port-doom-to-an-ikea-tradfri-lamp/+&amp;cd=3&amp;hl=en&amp;ct=clnk&amp;gl=ru&amp;client=safari">кэш Google</a>.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>В 2020 году сеть «взорвала» новость о том, что DOOM удалось запустить на тесте на беременность. По итогу история оказалась фейковой, но несмотря на это от неё всё же была польза.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f><a href="https://media.tproger.ru/uploads/2021/06/1-16.jpg"></a></p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Именно публикации о запуске легендарного шутера на таком примитивном устройстве, как тест на беременность, побудила ребят из next-hack портировать игру на что-то схожее по «уровню железа».</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>В итоге ими была найдена лампа ИКЕА TRÅDFRI, у которой был важный «плюс» — ARM-чип Cortex M33 с частотой 80 МГц. Но нашлось место и слабому месту — оперативной памяти в системе было всего 108 КБ.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Изучив все самые «нетребовательные» порты DOOM, энтузиасты выяснили, что есть версия игры, первый уровень в которой требует всего 87 КБ RAM. Таким образом, как минимум на бумаге, её можно было бы запустить на мощностях настольной лампы ИКЕА.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>По итогу, объединив её с 1.8-дюймовым TFT-дисплеем, DOOM заработала на 108 КБ оперативной памяти и 80 МГц чипе с частотой около 30 кадров в секунду. </p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>У проекта имеется свой GitHub-репозиторий. Он доступен по ссылке.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Как это выглядит, можете посмотреть ниже:</p><!--]--><!--[--><div class="tp-embed" data-type="embed" data-v-a1dfa206><span class="tp-embed-plug" data-v-a1dfa206></span></div><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Источник: <a href="https://next-hack.com/index.php/2021/06/12/lets-port-doom-to-an-ikea-tradfri-lamp/">next-hack.com</a></p><!--]--><!--]-->',
  original:
    "https://tproger.ru/news/video-doom-zapustili-na-lampe-ikea-s-108-kb-operativnoj-pamjati/",
  id: 163754,
  link: "https://tproger.ru/news/video-doom-zapustili-na-lampe-ikea-s-108-kb-operativnoj-pamjati/",
  slug: "video-doom-zapustili-na-lampe-ikea-s-108-kb-operativnoj-pamjati",
};
