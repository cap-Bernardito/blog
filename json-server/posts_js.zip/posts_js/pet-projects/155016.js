module.exports = {
  title: "Космический интернет OneWeb попытается легализоваться в России",
  views: "628",
  createdAt: "2021-04-09T17:17:41+00:00",
  img: "/images/tags-bell/tags-bell.png",
  type: ["Интернет", "Pet-проекты", "Илон Маск"],
  comments: [],
  html: '<!--[--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>OneWeb создаёт космический интернет. По сути, вместе со Starlink Илон Маска, это одна из немногих компаний, которая занимается развитием и распространением подобной технологии.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f><a href="https://media.tproger.ru/uploads/2021/04/1-19.jpg"></a></p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Сейчас же журналисты РБК пишут, что британская OneWeb запланировала легализоваться в России. Для этого она создаст наземные станции сопряжения. С их помощью спутники будут связываться с устройством пользователя для передачи интернета из космоса.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>После вступивших в 2019 году в силу поправок, это единственный способ легально работать на территории России. Тогда обновлённые законы начали требовать прохождения всего трафика от иностранных спутниковых устройств через станцию сопряжения российского оператора. Находиться она должна также на территории нашей страны.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Что интересно, буквально в конце марта Роскосмос отправил на орбиту 36 новых спутников OneWeb. Космические аппараты были одним из грузов ракеты-носителя Союз-2.1б.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Источник: <a href="https://www.rbc.ru/technology_and_media/09/04/2021/607055f89a794723210ae394?fromtg=1">РБК</a></p><!--]--><!--]-->',
  original:
    "https://tproger.ru/news/kosmicheskij-internet-oneweb-popytaetsja-legalizovatsja-v-rossii/",
  id: 155016,
  link: "https://tproger.ru/news/kosmicheskij-internet-oneweb-popytaetsja-legalizovatsja-v-rossii/",
  slug: "kosmicheskij-internet-oneweb-popytaetsja-legalizovatsja-v-rossii",
};
