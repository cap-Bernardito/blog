module.exports = {
  title: "Вышла стабильная версия PostgreSQL 12",
  views: "1834",
  createdAt: "2019-10-04T11:14:31+00:00",
  img: "/images/tags-bell/tags-bell.png",
  type: ["Инструменты", "Базы данных"],
  comments: [],
  html: '<!--[--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Автор: Андрей Карпов</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Состоялся релиз новой стабильной ветки СУБД PostgreSQL. Обновления PostgreSQL 12 будут выходить до ноября 2024.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Из интересных нововведений:</p><!--]--><!--[--><ul class="tp-content-list" style="" data-type="list" data-v-705dc74d><!--[--><li class="tp-content-list__item" data-v-705dc74d>Увеличена производительность индексирования. Индексы B-tree оптимизировали для случаев частого изменения — в тестах это позволило улучшить общую производительность на 40 %.</li><li class="tp-content-list__item" data-v-705dc74d>JIT-компилятор включён по умолчанию, это увеличит скорость выполнения выражений при обработке SQL-запросов.</li><li class="tp-content-list__item" data-v-705dc74d>Появилась поддержка хранимых «генерируемых столбцов». Это столбцы, содержимое которых вычисляется по выражению, основанному на содержимом других столбцов в этой таблице.</li><li class="tp-content-list__item" data-v-705dc74d>Оптимизировано секционирование для запросов на основе таблиц с большим количеством секций, если при этом запрос ограничивается определённым подмножеством данных.</li><li class="tp-content-list__item" data-v-705dc74d>Появилась поддержка автоматического inline-развёртывания обобщённых табличных выражений (Common Table Expression, CTE). Это должно повысить производительность большинства запросов. Пока используется только для нерекурсивных CTE.</li><li class="tp-content-list__item" data-v-705dc74d>При аутентификации через GSSAPI канал связи теперь шифруется и на серверной, и на клиентской стороне.</li><!--]--></ul><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Предыдущая версия <a href="https://tproger.ru/news/postgresql-11-released/">вышла</a> год назад.</p><!--]--><!--]-->',
  original: "https://tproger.ru/news/postgresql-12/",
  id: 119992,
  link: "https://tproger.ru/news/postgresql-12/",
  slug: "postgresql-12",
};
