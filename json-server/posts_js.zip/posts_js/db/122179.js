module.exports = {
  title: "В Яндекс.Облаке появился официальный сервис для MongoDB версии 4.2",
  views: "926",
  createdAt: "2019-11-14T14:41:36+00:00",
  img: "/images/tags-bell/tags-bell.png",
  type: ["Базы данных", "Яндекс", "Облачные технологии"],
  comments: [],
  html: '<!--[--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>«Яндекс» стала первым российским партнёром MongoDB. Сегодня компании подписали соглашение о сотрудничестве. Теперь в Яндекс.Облаке доступен <a href="https://cloud.yandex.ru/services/managed-mongodb">Managed Service for MongoDB</a> на основе актуальной версии официального сервиса под номером 4.2.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Команда Яндекс.Облака будет на связи с технической поддержкой MongoDB. В случае неполадок можно будет быстро проконсультироваться у российских специалистов. Кроме того, по словам компании, пользователи Яндекс.Облака получат доступ к новым функциям MongoDB, которых нет в более ранних версиях.</p><!--]--><!--]-->',
  original: "https://tproger.ru/news/yandex-managed-mongodb/",
  id: 122179,
  link: "https://tproger.ru/news/yandex-managed-mongodb/",
  slug: "yandex-managed-mongodb",
};
