module.exports = {
  title: "YouTube-видео превратили в бесконечное хранилище данных",
  views: "3285",
  createdAt: "2023-02-22T07:47:21+00:00",
  img: "/images/tags-bell/tags-bell.png",
  type: ["Big Data", "Базы данных", "Rust", "YouTube", "Новости"],
  comments: [],
  html: '<!--[--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Энтузиасты написали алгоритм AKA ISG, который превращает видео на YouTube в бесплатное бесконечное хранилище данных.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Суть алгоритма в том, что он позволяет вставлять файлы в видео и загружать их на YouTube в качестве хранилища. Все файлы состоят из байтов, а байты можно интерпретировать как числа. Каждый пиксель либо белый — 1, либо чёрный — 0.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f><b>В итоге получается вот такое видео, каждый кадр которого содержит в себе информацию:</b></p><!--]--><!--[--><div class="tp-embed" data-type="embed" data-v-a1dfa206><span class="tp-embed-plug" data-v-a1dfa206></span></div><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>«YouTube не имеет ограничений на количество видео, которые вы можете загрузить. Это означает, что это фактически бесконечное облачное хранилище», — говорит разработчик в описании проекта.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>А что, прогресс хранения данных налицо: от магнитофонных кассет до видео на ютубе.</p><!--]--><!--[--><blockquote class="tp-content-hint" fullwidth="true" data-type="hint" data-v-640486f3>Исходники написаны на Rust и лежат на гитхабе.</blockquote><!--]--><!--]-->',
  original:
    "https://tproger.ru/articles/youtube-video-prevratili-v-beskonechnoe-hranilishhe-dannyh/",
  id: 237312,
  link: "https://tproger.ru/articles/youtube-video-prevratili-v-beskonechnoe-hranilishhe-dannyh/",
  slug: "youtube-video-prevratili-v-beskonechnoe-hranilishhe-dannyh",
};
