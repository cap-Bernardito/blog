module.exports = {
  title:
    "Facebook анонсировала перелицензирование React, Jest, Flow и Immutable.js",
  views: "1515",
  createdAt: "2017-09-24T15:46:16+00:00",
  img: "/images/tags-bell/tags-bell.png",
  type: ["JavaScript", "Инструменты", "React"],
  comments: [],
  html: '<!--[--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Все новые версии этих программ Facebook будут выпускаться под <a href="https://tproger.ru/articles/whats-difference-between-licenses/">лицензией MIT</a>. Об этом представители компании <a href="https://code.facebook.com/posts/300798627056246/relicensing-react-jest-flow-and-immutable-js/">заявили</a> в своём блоге. Стоит отметить, что в июле Apache <a href="https://www.opennet.ru/opennews/art.shtml?num=46860">добавила</a> BSD+Patent в список лицензий, программы под которыми не разрешается использовать в проектах компании.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Facebook приняла решение перелицензировать свои продукты, так как не хочет сдерживать технический прогресс в использовании React, Jest и Flow такими нетехническими причинами, как лицензирование продуктов. При этом компания продолжает верить, что выбранный ими ранее тип лицензии предоставлял больше преимуществ.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Изменение правил лицензирования указанных проектов не повлияет на другие программы Facebook, и решение по их возможному уходу от лицензии BSD+Patent будет приниматься для каждого продукта индивидуально.</p><!--]--><!--]-->',
  original: "https://tproger.ru/news/relicensing-facebooks-products/",
  id: 49389,
  link: "https://tproger.ru/news/relicensing-facebooks-products/",
  slug: "relicensing-facebooks-products",
};
