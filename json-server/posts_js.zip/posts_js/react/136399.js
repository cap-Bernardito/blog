module.exports = {
  title: "Создание приложений для Windows на React Native",
  views: "7432",
  createdAt: "2020-11-04T13:24:23+00:00",
  img: "/images/tags-bell/tags-bell.png",
  type: ["Open Source", "Windows", "React"],
  comments: [],
  html: '<!--[--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f><a href="https://reactnative.dev/">React Native</a> — это платформа, позволяющая создавать мобильные приложения на основе JavaScript и React. Разработана Facebook и применяется во многих мировых проектах, среди которых Instagram, Discord, Pinterest, Bloomberg, Wix и другие.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Приложения на React Native имеют согласованный интерфейс: учитесь один раз — пишите где угодно.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f><a href="https://media.tproger.ru/uploads/2020/11/hero2.png"></a></p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Благодаря репозиторию <a href="https://github.com/Microsoft/react-native-windows">React Native for Windows</a> приложения на React можно писать для <a href="https://ru.wikipedia.org/wiki/%D0%A3%D0%BD%D0%B8%D0%B2%D0%B5%D1%80%D1%81%D0%B0%D0%BB%D1%8C%D0%BD%D0%B0%D1%8F_%D0%BF%D0%BB%D0%B0%D1%82%D1%84%D0%BE%D1%80%D0%BC%D0%B0_Windows">UWP (Universal Windows Platform)</a>, а значит под все устройства, которые поддерживают Windows 10 (ПК, планшеты, Xbox, устройства смешанной реальности).</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Узнать подробней и начать изучать этот проект можно по его <a href="https://microsoft.github.io/react-native-windows/docs/getting-started">документации</a>. Так же можно <a href="https://reactnative.dev/docs/getting-started">ознакомиться с React Native</a> в целом. Следить за последними событиями можно в <a href="https://microsoft.github.io/react-native-windows/blog/">блоге</a>.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>React Native for Windows — это open source проект. Вы сможете помочь им, предложив какую-нибудь фичу или решив имеющуюся проблему.</p><!--]--><!--[--><div class="tp-embed" data-type="embed" data-v-a1dfa206><span class="tp-embed-plug" data-v-a1dfa206></span></div><!--]--><!--]-->',
  original: "https://tproger.ru/articles/windows-application-on-react/",
  id: 136399,
  link: "https://tproger.ru/articles/windows-application-on-react/",
  slug: "windows-application-on-react",
};
