module.exports = {
  title:
    "iPod.js — веб-версия легендарного плеера с авторизацией через Spotify и Apple Music",
  views: "1777",
  createdAt: "2021-06-24T08:56:02+00:00",
  img: "/images/tags-bell/tags-bell.png",
  type: [
    "JavaScript",
    "Веб-разработка",
    "Apple",
    "CSS",
    "Музыка",
    "GitHub",
    "TypeScript",
    "React",
    "Фронтенд",
    "Spotify",
  ],
  comments: [],
  html: '<!--[--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Пользователь Hacker News под ником tonyhawkins поделился интересной находкой. Проект iPod.js, как понятно из названия, представляет из себя онлайн вариант легендарного плеера Apple.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Сервис представляет из себя <a href="https://tannerv.com/ipod/">сайт-одностраничник</a>, в центре которого расположился iPod Classic. Пользователь может перемещаться по меню, используя либо клавиатуру, либо через Click Wheel — знаменитый орган управления плеера.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Причём принцип его работы такой же, как на настоящем плеер — надо зажать мышкой и провести по кругу, чтобы двигаться по пункта меню.</p><!--]--><!--[--><div class="tp-video" data-type="video" data-v-1d4b1aac><video class="tp-video__player" height="470" width="300" controls muted data-v-1d4b1aac></video></div><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Для того, чтобы слушать музыку на iPod.js, пользователям предлагается авторизоваться. Это можно сделать с помощью своего аккаунта в Spotify или Apple Music.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f><a href="https://media.tproger.ru/uploads/2021/06/1_1-6.png"></a></p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>При этом автор проекта под ником tannerv оставил в виртуальном iPod приятную пасхалку. Перейдя в меню Games можно сыграть в классическую аркаду — Арканоид.</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f><a href="https://media.tproger.ru/uploads/2021/06/1_2-2.png"></a></p><!--]--><!--[--><h3 class="tp-content-subtitle tp-content-subtitle--h3" data-type="header3" data-v-75e770f1>Какие технологии использовались для создания iPod.js?</h3><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>По словам автора, фронтенд проекта делался на JavaScript (TypeScript и React) и CSS. Для связки с музыкальными сервисами использовались Spotify Web Playback SDK и Apple MusicKit JS.</p><!--]--><!--[--><h3 class="tp-content-subtitle tp-content-subtitle--h3" data-type="header3" data-v-75e770f1>Где узнать подробности создания проекта?</h3><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>В <a href="https://github.com/tvillarete/ipod-classic-js">GitHub-репозитории</a> iPod.js</p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f><a href="https://media.tproger.ru/uploads/2021/06/Screenshot-2021-06-24-at-11.43.42.png"></a></p><!--]--><!--[--><p class="tp-content-paragraph" data-type="paragraph" data-v-6c80349f>Источник: <a href="https://news.ycombinator.com/item?id=27606099">Hacker News</a></p><!--]--><!--]-->',
  original:
    "https://tproger.ru/news/ipod-js-veb-versija-legendarnogo-pleera-s-avtorizaciej-cherez-spotify-i-apple-music/",
  id: 165175,
  link: "https://tproger.ru/news/ipod-js-veb-versija-legendarnogo-pleera-s-avtorizaciej-cherez-spotify-i-apple-music/",
  slug: "ipod-js-veb-versija-legendarnogo-pleera-s-avtorizaciej-cherez-spotify-i-apple-music",
};
